me = {
    "first_name": "Elizabeth",
    "last_name": "K",
    "color":"red",    # preffered color
    "hobbies": [],
    "address": {
        "number": 42,
        "street": "evergreen",
        "city": "springfield"
        }
    }

catalog  = [
    {
        "_id": "09123asjlkd098712lkasd",
        "title": "Kelp Noodle",
        "price": 18.00,
        "category": "Dinner",
        "image": "dinnerkelp.jpg"
    },

    {
        "_id": "09123asjlkd098712lkas2",
        "title": "Raw sushi",
        "price": 12.00,
        "category": "Dinner",
        "image": "dinnesushi.jpg"
    },

    {
        "_id": "09123asjlkd098712lkas2",
        "title": "Raw sandwich",
        "price": 15.00,
        "category": "Dinner",
        "image": "dinnersandwich.jpg"
    },

    {
        "_id": "09123asjlkd098712lkas4",
        "title": "Onion bread",
        "price": 12.00,
        "category": "Snack",
        "image": "onionbread.jpg"
    },
    {
        "_id": "09123asjlkd098712lkas4",
        "title": "Kacao ",
        "price": 12.00,
        "category": "Snack",
        "image": "onionbread.jpg"
    },
    {
        "_id": "09123asjlkd098712lkas4",
        "title": "Onion bread",
        "price": 12.00,
        "category": "Snack",
        "image": "onionbread.jpg"
    }
]